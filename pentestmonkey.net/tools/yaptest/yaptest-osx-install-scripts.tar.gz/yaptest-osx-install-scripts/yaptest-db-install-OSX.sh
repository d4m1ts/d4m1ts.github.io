#!/bin/sh

PATH=$PATH:/opt/local/lib/postgres80/bin
createuser -a -d postgres 

if [ $# != 1 ]; then
	echo "Usage: $0 yaptest_template.sql"
	exit 0;
fi

YAPTEST_TEMPLATE_SQL=$1
YAPTEST_TEMPLATE_NAME=yaptest_template
EXISTING_DATABASE=template1

echo "update pg_database set datistemplate = 'f', datallowconn = 't' where datname = '"$YAPTEST_TEMPLATE_NAME"';" | psql $EXISTING_DATABASE

dropdb $YAPTEST_TEMPLATE_NAME
echo "DROP USER yaptest_user;" | psql $EXISTING_DATABASE

createdb $YAPTEST_TEMPLATE_NAME
echo "CREATE USER yaptest_user;" | psql $YAPTEST_TEMPLATE_NAME
# for 8.1 update pg_authid set rolecreatedb = 't' ...
echo "update pg_shadow set usecreatedb = 't' where usename = 'yaptest_user';" | psql $YAPTEST_TEMPLATE_NAME
cat $YAPTEST_TEMPLATE_SQL | psql $YAPTEST_TEMPLATE_NAME

echo "update pg_database set datistemplate = 't', datallowconn = 't' where datname = '"$YAPTEST_TEMPLATE_NAME"';" | psql $YAPTEST_TEMPLATE_NAME



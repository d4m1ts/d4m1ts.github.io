#!/bin/sh

if [ $# != 3 ]; then
	echo "Usage: $0 bindir datadir"
	echo "e.g. $0 /usr/local/bin /usr/local/share/yaptest /usr/local/lib/site_perl"
	exit 0;
fi

BINDIR=$1
DATADIR=$2
PERLDIR=$3
UID=`id root | cut -d= -f2| cut -d\( -f 1`
GID=`id root | cut -d= -f3| cut -d\( -f 1`
mkdir -p -m 0755 $BINDIR $DATADIR $PERLDIR

echo "Installing program files to $BINDIR"
for FILE in `cat program-files.txt`; do 
	install -m 0755 -o $UID -g $GID $FILE $BINDIR
done

echo "Installing data files to $DATADIR"
for FILE in `cat data-files.txt`; do 
	install -m 0644 -o $UID -g $GID $FILE $DATADIR
done

echo "Installing PERL modules to $PERLDIR"
for FILE in `cat perl-module-files.txt`; do 
	install -m 0644 -o $UID -g $GID $FILE $PERLDIR
done


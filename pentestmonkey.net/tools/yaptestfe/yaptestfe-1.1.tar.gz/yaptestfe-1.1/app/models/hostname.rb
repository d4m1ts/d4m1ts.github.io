class Hostname < ActiveRecord::Base
end

class InsecureProtocol < ActiveRecord::Base
	set_table_name "view_insecure_protos"
end

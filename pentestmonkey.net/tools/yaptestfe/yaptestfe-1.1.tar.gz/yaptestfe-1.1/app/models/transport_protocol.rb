class TransportProtocol < ActiveRecord::Base
end

class Host < ActiveRecord::Base
	set_table_name "view_hosts"
	set_primary_key "host_id"
end

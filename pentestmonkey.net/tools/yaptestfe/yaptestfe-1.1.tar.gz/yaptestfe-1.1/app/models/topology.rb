class Topology < ActiveRecord::Base
	set_table_name "view_topology"
end

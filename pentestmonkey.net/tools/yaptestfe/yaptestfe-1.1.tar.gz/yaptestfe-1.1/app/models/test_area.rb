class TestArea < ActiveRecord::Base
end

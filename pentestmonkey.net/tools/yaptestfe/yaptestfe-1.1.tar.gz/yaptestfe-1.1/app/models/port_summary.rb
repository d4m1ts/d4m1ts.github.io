class PortSummary < ActiveRecord::Base
	set_table_name "view_port_summary"
end

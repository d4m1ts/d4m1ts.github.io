class PasswordHash < ActiveRecord::Base
	set_table_name "view_password_hashes"
end

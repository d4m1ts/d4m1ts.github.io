class MacAddresses < ActiveRecord::Base
end

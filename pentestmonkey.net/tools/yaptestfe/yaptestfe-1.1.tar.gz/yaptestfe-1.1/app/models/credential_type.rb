class CredentialType < ActiveRecord::Base
end

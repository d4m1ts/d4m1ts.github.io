class Interface < ActiveRecord::Base
	set_table_name "view_interfaces"
end

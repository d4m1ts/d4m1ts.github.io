class PortKey < ActiveRecord::Base
end

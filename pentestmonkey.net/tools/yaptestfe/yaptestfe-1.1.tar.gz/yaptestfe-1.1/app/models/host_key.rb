class HostKey < ActiveRecord::Base
end

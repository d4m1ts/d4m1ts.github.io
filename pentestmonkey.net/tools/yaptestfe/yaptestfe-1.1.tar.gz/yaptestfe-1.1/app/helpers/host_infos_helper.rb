module HostInfosHelper
end
